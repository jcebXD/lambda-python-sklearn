# flake8: noqa

import pandas.rpy.util as util


class lm(object):
    """
    Examples
    --------
    >>> model = lm('x ~ y + z', data)
    >>> model.coef
    """
    def __init__(self, formula, data):
        pass
